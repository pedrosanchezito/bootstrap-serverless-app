import os
import json
import boto3
from datetime import datetime

def lambda_handler(event, context):

    error_output = {"statusCode": 400, "body": "Please enter a username and message"}

    if event['body']:
        username = json.loads(event['body'])['username'] if 'username' in json.loads(event['body']) else None
        creation_date = json.loads(event['body'])['creation_date'] if 'creation_date' in json.loads(event['body']) else str(datetime.timestamp(datetime.now()))
        message = json.loads(event['body'])['message'] if 'message' in json.loads(event['body']) else None
        last_edited = str(datetime.timestamp(datetime.now()))
        
        client = boto3.client('dynamodb')
        tablename = '{}-tweets'.format(os.environ['env'])
        
        if username and message:
            response = client.put_item(
                TableName=tablename,
                Item={
                    'username': {'S': username},
                    'creation_date': {'S': creation_date},
                    'message': {'S': message},
                    'last_edited': {'S': last_edited}
                    }
            )
            output = {
                    'statusCode': 201,
                    'body': json.dumps(response)
            }
        else:
            output = error_output
    else:
        output = error_output

    return output
