import os
import json
import boto3

def lambda_handler(event, context):

    if event['queryStringParameters']:
        username = event['queryStringParameters']['username'] if 'username' in event['queryStringParameters'] else None
        creation_date = event['queryStringParameters']['creation_date'] if 'creation_date' in event['queryStringParameters'] else None
    else:
        username = None
        creation_date = None

    tablename = '{}-tweets'.format(os.environ['env'])
    client = boto3.client('dynamodb')

    if username and creation_date:
        response = client.get_item(
            TableName=tablename,
            Key={
                'username': {'S': username},
                'creation_date': {'S': creation_date}
            }
        )
    elif username:
        response = client.query(
            TableName=tablename,
            KeyConditionExpression='username = :username',
            ExpressionAttributeValues={':username': {'S': username}}
        )
    else:
        response = client.scan(TableName=tablename)
      
    return {
        'statusCode': 200,
        'body': json.dumps(response)
    }

