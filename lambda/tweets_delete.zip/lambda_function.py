import os
import json
import boto3

def lambda_handler(event, context):

    error_output = {"statusCode": 400, "body": "No tweet found for this user and date"}

    if event['body']:
        username = json.loads(event['body'])['username'] if 'username' in json.loads(event['body']) else None
        creation_date = json.loads(event['body'])['creation_date'] if 'creation_date' in json.loads(event['body']) else None

        client = boto3.client('dynamodb')
        tablename = '{}-tweets'.format(os.environ['env'])

        if username and creation_date:
            response = client.delete_item(
                TableName=tablename,
                Key={
                    'username': {'S': username},
                    'creation_date': {'S': creation_date}
                }
            )
            output = {
                'statusCode': 200,
                'body': json.dumps(response)
            }
        else:
            output = error_output
    else:
        output = error_output

    return output
